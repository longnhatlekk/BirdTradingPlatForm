﻿namespace BirdPlatFormEcommerce.Payment
{
    public enum PaymentMethod
    {
        Cash,
        VnPay
    }
}
