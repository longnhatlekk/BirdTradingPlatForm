﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class ViewAccount
    {
        public DateTime Dob { get; set; }
  
        public string userName { get; set; }
        public string Email { get; set; }
        public string Gender { get; set;}
        public string Phone { get; set; }
        public string Address { get; set; }
        public string avatar { get; set; }
    }
}
