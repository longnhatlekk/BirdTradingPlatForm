﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class ForgotPassword
    {
        public string Email { get; set; }
    }
}
