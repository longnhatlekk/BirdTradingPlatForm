﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class CreateAvatarUserVm
    {

        public IFormFile Avatar { get; set; }
    }
}
