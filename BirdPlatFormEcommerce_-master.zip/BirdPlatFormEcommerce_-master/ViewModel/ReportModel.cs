﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class ReportModel
    {
        public int shopId { get; set; }
        
        public int Count { get; set;}
    }
}
