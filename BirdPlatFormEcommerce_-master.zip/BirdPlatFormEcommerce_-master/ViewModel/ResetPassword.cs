﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class ResetPassword
    {
        public string Email { get; set; }
       
    }
}
