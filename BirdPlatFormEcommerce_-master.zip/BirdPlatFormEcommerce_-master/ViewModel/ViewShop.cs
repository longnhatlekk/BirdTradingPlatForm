﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class ViewShop
    {
        public int ShopId { get; set; }
        public int? Rate { get; set; }
        public string shopName { get; set; }
        public string Address {get; set; }
        public string phone { get; set; }   
        public string Description { get; set; }
        public string AddressDetail { get; set; }

    }
}
