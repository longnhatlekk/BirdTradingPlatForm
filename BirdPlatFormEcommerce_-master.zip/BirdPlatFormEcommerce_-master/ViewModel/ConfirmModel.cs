﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class ConfirmModel
    {
        public int OrderId { get; set; }
        public int? ToConfirm { get; set; }
        public DateTime? ConfirmDate { get; set; }
    }
}
