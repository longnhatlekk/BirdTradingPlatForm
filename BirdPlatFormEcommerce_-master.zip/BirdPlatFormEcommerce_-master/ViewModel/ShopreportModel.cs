﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class ShopreportModel
    {
        public int reportID { get; set; }
        public string detail { get; set; }
        public string DetailCate { get; set; }
    }
}
