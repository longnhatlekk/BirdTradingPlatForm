﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class ReportShopModel
    {
        public string Detail { get; set; }
        
        public int? ShopId { get; set;}
       
        public int categoriaId { get; set; }
    }
}
