﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class WarningModel
    {
        public string Subject { get; set; }

        public string Message { get; set; }
    }
}
