﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class Inforproduct
    {
        public int OrderID { get; set; }
    public int ProductID { get; set; }
    public string ProductName { get; set; }
    public int Quantity { get; set; }
    public decimal SubTotal { get; set; }
    public int ShopID { get; set; }
    public string ShopName { get; set; }
    public string ImagePath { get; set; }
    }
}
