﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class AddressModel
    {
        public string Address { get; set; }

        public string AddressDetail { get; set; }

        public string Phone { get; set; }

        public string NameRg { get; set; }
    }
}
