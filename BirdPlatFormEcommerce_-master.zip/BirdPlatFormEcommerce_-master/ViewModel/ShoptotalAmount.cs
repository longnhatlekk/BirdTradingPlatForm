﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class ShoptotalAmount
    {
     
        public decimal? Total { get; set; }
        public DateTime? OrderDate { get; set; }
        public string shopName { get; set; }
        public int ShopId { get; set; }
    }
}
