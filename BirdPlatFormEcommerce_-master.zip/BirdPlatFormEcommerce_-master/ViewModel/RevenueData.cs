﻿namespace BirdPlatFormEcommerce.ViewModel
{
    public class RevenueData
    {
        public decimal[] DailyRevenue { get; set; }
        public string[] Weekdays { get; set; }
    }
}
