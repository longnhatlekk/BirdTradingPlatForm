﻿namespace BirdPlatForm.UserRespon
{
    public class TokenRespon
    {
        public string AccessToken { get; set; }
      
    }
}
