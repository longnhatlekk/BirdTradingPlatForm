﻿namespace BirdPlatForm.UserRespon
{
    public class ErrorRespon
    {
        public bool Error { get; set; }
        public string Message { get; set; }
        public object Data { get; set; }
        public string RoleId { get; set; }
    }

}
