﻿

using BirdPlatFormEcommerce.NEntity;

namespace BirdPlatFormEcommerce.Product
{
    public interface IManageOrderService
    {

      

       
    }
}



