﻿namespace BirdPlatFormEcommerce.Product
{
    public class ListProductImageCreateRequest
    {
        public bool? IsDefault { get; set; }
        public int? SortOrder { get; set; }
    }
}
